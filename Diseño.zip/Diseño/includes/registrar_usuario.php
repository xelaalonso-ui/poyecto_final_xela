<?php

include_once("./usuario.php");

$nombre = $_POST['nombre'];
$fecha_nacimiento = $_POST['fecha'];
$correo = $_POST['correo'];
$clave = $_POST['clave'];

$rol = $_POST['rol'];
$hash = password_hash($clave, PASSWORD_DEFAULT);



$nombreAchivo = null;
$archiboBinario = null;
$tipoImagen = null;

if ($_FILES['imagen']['name'] <> '') {
    $nombreAchivo = $_FILES["imagen"]["name"];
    $archiboBinario = addslashes(file_get_contents($_FILES['imagen']['tmp_name']));
    $tipoImagen = $_FILES['imagen']['type'];
} 
    // Creamos un objeto cliente con esos datos para poder utilizar el método que lo inserte la base de datos
    $usuario = new usuario();
    $usuario->crearUsuario($nombre, $fecha_nacimiento, $correo, $hash, $nombreAchivo, $archiboBinario, $tipoImagen, $rol);
    $usuario->insertar();


    header('Location:../login.php?registro=exitoso');
