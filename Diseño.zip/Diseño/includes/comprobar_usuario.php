<?php
include_once('./usuario.php');

$clave = $_POST['clave'];
$correo = $_POST['correo'];
include_once('./db_connection.php');

$query = "select* from usuario where correo='$correo'";

if (!$result = mysqli_query($db, $query)) {
    exit(mysqli_error($db));
} else {
    $fila = mysqli_fetch_assoc($result);
}

mysqli_free_result($result);
mysqli_close($db);
$id = $fila['id'];
$hash = $fila['clave'];
$nombre = $fila['nombre'];
$fecha_nacimiento = $fila['fecha_nacimiento'];
$correo = $fila['correo'];

$rol = $fila['rol'];
$nombre_imagen = $fila['nombre_imagen'];
$imagen = $fila['imagen'];
$tipo_imagen = $fila['tipo_imagen'];

if ($nombre_imagen <> '') {
    $imagenbase64 = base64_encode($imagen);
    $tipoimagen = $tipo_imagen;
    $urlimagen = "data:$tipoimagen;base64,$imagenbase64";
} else {
    $urlimagen = "./img/orgulloso.png";
}

if (password_verify($clave, $hash)) {
    session_start();
    $_SESSION['id'] = $id;
    $_SESSION['nombre'] = $nombre;
    $_SESSION['fecha_nacimiento'] = $fecha_nacimiento;
    $_SESSION['correo'] = $correo;
    $_SESSION['rol'] = $rol;
    $_SESSION['nombre_imagen'] = $nombre_imagen;
    $_SESSION['imagen'] = $urlimagen;



    header('location:../index.php');
} else {
    header('location:../login.php');
}
