<?php
function mostrarUsuarios()
{
    include("db_connection.php");
    include_once("usuario.php");
    $data = array();
    $query = "SELECT * FROM usuario";
    $result = mysqli_query($db, $query);
    if (!$result) {
        exit(mysqli_error($db));
    } else {
        $fila = mysqli_fetch_assoc($result);
        while ($fila) {
            // $usuario= new usuario();
            // $usuario->setId($fila['id']);
            // $usuario->crearUsuario($fila['nombre'], $fila['fecha_nacimiento'], $fila['correo'],$fila['clave'], $fila['rol'],$fila['nombre_imagen'],$fila['imagen'],$fila['tipo_imagen']);

            $data[] = $fila;
            $fila = mysqli_fetch_assoc($result);
        }
        
    }
    mysqli_free_result($result);
    
    mysqli_close($db);
    
    return $data;
}

