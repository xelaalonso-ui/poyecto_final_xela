<?php
include_once("./usuario.php");
$id=$_GET['id'];
$usuario=new usuario();
$usuario->setId($id);
$usuario->eliminar();
header("location: ../lista_usuarios.php");
?>