<?php
include_once("./usuario.php");
session_start();
$id = $_SESSION['id'];
$nombre = $_POST['nombre'];
$fecha_nacimiento = $_POST['fecha'];
$correo = $_POST['correo'];
$clave = $_POST['clave'];

if ($clave <> '') {
    $hash = password_hash($clave, PASSWORD_DEFAULT);
} else {
    $hash = '';
}


$nombreAchivo = '';
$archiboBinario = '';
$tipoImagen = '';

if ($_FILES['imagen']['name'] <> '') {
    $nombreAchivo = $_FILES["imagen"]["name"];
    $archiboBinario = addslashes(file_get_contents($_FILES['imagen']['tmp_name']));
    $tipoImagen = $_FILES['imagen']['type'];
}



$usuario = new usuario();

$usuario->editarUsuario($id, $nombre, $fecha_nacimiento, $correo, $hash, $nombreAchivo, $archiboBinario, $tipoImagen);
$usuario->editar();
$_SESSION['nombre'] = $nombre;
$_SESSION['fecha'] = $fecha_nacimiento;
$_SESSION['correo'] = $correo;

if ($nombreAchivo <> '') {
    $imagenbase64 = base64_encode($archiboBinario);
    $urlimagen = "data:$tipoimagen;base64,$imagenbase64";
}
$_SESSION['imagen'] = $urlimagen;


header("location: ./cerrar_ssion.php");
